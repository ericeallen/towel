from pathlib import Path
import hashlib,json
configs={'typing_extensions': ['.pre-commit-config.yaml', 'pyproject.toml', 'tox.ini'], 'cheroot': ['.mypy.ini', '.pre-commit-config.yaml', 'pyproject.toml', 'tox.ini']}
print(json.dumps({name:{f:hashlib.sha256((Path('/work')/name/f).read_bytes()).hexdigest() for f in files} for name,files in configs.items()},indent=2))
