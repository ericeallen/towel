"""Continue already authorized mechanical gates, without claiming release acceptance.

The original driver owns the corpus and its evidence. This process only observes
its completed records. Any new failure or resource problem stops the queue for
review. Reviewed historical refusal/fallback categories permit the independent
matrix to proceed; final corpus assessment and documentation remain human/agent
work. No pushes, publication, source changes, or recurring scheduler.
"""
from datetime import datetime, timezone
from pathlib import Path
import json
import subprocess
import time

ROOT = Path(__file__).resolve().parent


def now():
    return datetime.now(timezone.utc).isoformat()


def record(name):
    return json.loads((ROOT / name).read_text())


def run():
    deadline = time.monotonic() + 12 * 3600
    while True:
        complete = ROOT / 'corpus-driver.log'
        if complete.exists() and any(line.startswith('END corpus ') for line in complete.read_text().splitlines()):
            break
        if time.monotonic() >= deadline:
            raise RuntimeError('Corpus completion was not recorded within 12 hours; inspect, do not restart.')
        print(now(), 'Waiting for complete corpus evidence; no matrix started.', flush=True)
        time.sleep(50)
    with (ROOT / 'corpus-reconciliation-driver.log').open('w') as log:
        subprocess.run(['python3', str(ROOT / 'validate-corpus-records.py')], stdout=log, stderr=subprocess.STDOUT, check=True)
    result = record('corpus-reconciliation.json')
    expected_refusals = {'isort', 'invoke', 'towel-v1.414', 'towel-v1.618', 'towel-main'}
    assert set(result['nonaccepted']) <= expected_refusals, result['nonaccepted']
    assert all(verdict == 'CRASH' for verdict in result['nonaccepted'].values()), result['nonaccepted']
    assert set(result['fallbacks']) <= {'trio', 'typing_extensions', 'cheroot'}, result['fallbacks']
    assert set(result['known_failures']) <= {'pyparsing'}, result['known_failures']
    for name in result['nonaccepted']:
        project = record(f'corpus-report/{name}.json')
        assert project['changed_files'] == 0 and project['after'] is None, name
        assert project['baseline'] is not None and project['baseline']['returncode'] in (0, 1), name
        assert project['refactor']['returncode'] == 1, name
        log = (ROOT / 'corpus-logs' / Path(project['refactor']['log']).name).read_text()
        assert 'For a ' in log and ('the installed project' in log or 'stray copy' in log or 'copy installed outside the project' in log), name
    rows = {row['name']: row for row in record('corpus-report/summary.json')['results']}
    assert rows['towel-main']['baseline']['returncode'] == 0
    assert rows['towel-main']['verdict'] in {'PASS', 'NO_CHANGE', 'CRASH'}
    assert rows['tornado']['verdict'] == rows['chardet']['verdict'] == 'PASS'
    assert rows['blinker']['verdict'] == 'NO_CHANGE' and not rows['blinker']['fallback']
    for name in ('tornado', 'chardet', 'blinker', 'sphinx'):
        assert rows[name]['typing_mode'] == 'default' and not rows[name]['fallback'], name
    review = {'recorded': now(), 'commit': result['commit'], 'scope': 'Mechanical prerequisite checks only; final corpus semantic assessment remains required.', 'projects': result['projects'], 'nonaccepted': result['nonaccepted'], 'fallbacks': result['fallbacks'], 'known_failures': result['known_failures'], 'corpus_oom_killed': record('corpus-exit.json')['oom_killed'], 'towel_main_baseline_completed': rows['towel-main']['baseline'], 'matrix_authorized_to_run': True}
    (ROOT / 'mechanical-corpus-review.json').write_text(json.dumps(review, indent=2) + '\n')
    print(now(), 'Recorded corpus prerequisites passed; running serial Linux matrix.', flush=True)
    assert not (ROOT / 'matrix-driver.log').exists(), 'Inspect existing matrix instead of overwriting.'
    with (ROOT / 'matrix-driver.log').open('w') as log:
        subprocess.run(['python3', '-u', str(ROOT / 'run-matrix.py')], cwd=ROOT, stdout=log, stderr=subprocess.STDOUT, check=True)
    for version in ('3.11', '3.13', '3.12'):
        step = record(f'matrix-{version}-result.json')
        assert step['exit_status'] == 0 and step['commit'] == result['commit'], version
        state = record(f'matrix-{version}-container.json')[0]['State']
        assert not state['Running'] and not state['OOMKilled'] and state['ExitCode'] == 0, version
    print(now(), 'Mechanical matrix finished; final evidence review/documentation still required.', flush=True)


try:
    run()
except BaseException as error:
    (ROOT / 'continuation-result.json').write_text(json.dumps({'finished': now(), 'status': 'stopped_for_review', 'error': repr(error)}, indent=2) + '\n')
    raise
else:
    (ROOT / 'continuation-result.json').write_text(json.dumps({'finished': now(), 'status': 'mechanical_gates_complete', 'final_acceptance': False}, indent=2) + '\n')
