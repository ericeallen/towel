from pathlib import Path
import datetime
import hashlib
import json
import os
import subprocess
import time

root=Path(__file__).resolve().parent
env={**os.environ,'UV_CACHE_DIR':'/private/tmp/towel-post-1772-uv-cache','UV_OFFLINE':'1'}
args=['uv','run','--frozen','towel','dry','src/towel',str(root/'selfdogfood/generated'),'--no-interactive','--progress','detail']
started=datetime.datetime.now(datetime.timezone.utc).isoformat();clock=time.monotonic()
print('START self-generation',started,flush=True)
with (root/'selfdogfood.log').open('w') as log:
    result=subprocess.run(args,cwd=root/'candidate',env={**env,'TOWEL_WORKERS':'1'},stdout=log,stderr=subprocess.STDOUT)
(root/'self-generation-result.json').write_text(json.dumps({'args':args,'TOWEL_WORKERS':'1','started':started,'finished':datetime.datetime.now(datetime.timezone.utc).isoformat(),'seconds':time.monotonic()-clock,'exit_status':result.returncode},indent=2)+'\n')
print('END self-generation',result.returncode,flush=True)
if result.returncode:raise SystemExit(result.returncode)
result=subprocess.run(['python3',str(root/'run-self-project.py')],cwd=root,env=env)
if result.returncode:raise SystemExit(result.returncode)
source=json.loads((root/'selfdogfood/source.json').read_text())
for row in source['runtime_files']:
    actual=root/'selfdogfood/project'/row['path']
    generated=root/'selfdogfood/generated'/Path(row['path']).relative_to('src/towel')
    assert actual.read_bytes()==generated.read_bytes()
    assert hashlib.sha256(actual.read_bytes()).hexdigest()==row['after']
assert not subprocess.check_output(['git','-C',str(root/'candidate'),'status','--porcelain'],text=True)
(root/'selfdogfood/post-test-integrity.json').write_text(json.dumps({'input_commit':source['input_commit'],'transformed_runtime_files_unchanged_by_test_run':len(source['runtime_files']),'all_generated_runtime_files_included':True,'frozen_candidate_still_clean':True},indent=2)+'\n')
print('POST-TEST INTEGRITY passed',flush=True)
