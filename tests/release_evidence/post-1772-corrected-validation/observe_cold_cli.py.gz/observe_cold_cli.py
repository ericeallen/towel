"""Observe the installed CLI's actual final checker reset; do not replace its result."""
import json
import os
from pathlib import Path
import towel
from towel import cli
from towel.unification import annotation_wiring

original = annotation_wiring.start_cold
observed = []
def start_cold(oracle):
    original(oracle)
    observed.append(type(oracle).__name__)
annotation_wiring.start_cold = start_cold
try:
    cli.main()
finally:
    Path(os.environ['TOWEL_SMOKE_COLD_RECORD']).write_text(json.dumps({'source':towel.__file__, 'resets':observed})+'\n')
