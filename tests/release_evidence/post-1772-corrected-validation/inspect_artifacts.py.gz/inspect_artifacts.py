from pathlib import Path
import email
import hashlib
import json
import subprocess
import tarfile
import zipfile

root = Path(__file__).resolve().parent
source = root / 'candidate'
wheel = root / 'dist/code_towel-1.772-py3-none-any.whl'
sdist = root / 'dist/code_towel-1.772.tar.gz'
expected = {str(p.relative_to(source / 'src')): p.read_bytes() for p in (source / 'src/towel').rglob('*.py')}
with zipfile.ZipFile(wheel) as z:
    actual = {name: z.read(name) for name in z.namelist() if name.startswith('towel/') and name.endswith('.py')}
    assert actual == expected, 'Wheel Python files differ from frozen source'
    assert z.read('towel/py.typed') == (source / 'src/towel/py.typed').read_bytes()
    assert any(name.endswith('/licenses/LICENSE') for name in z.namelist())
    metadata = email.message_from_string(z.read('code_towel-1.772.dist-info/METADATA').decode('utf-8'))
    assert metadata['Name'] == 'code-towel' and metadata['Version'] == '1.772'
    assert metadata.get_payload().strip() == (source / 'README.md').read_text().strip()
    assert metadata['Requires-Python'] == '>=3.11'
    assert set(metadata.get_all('Provides-Extra')) == {'dev','format','types'}
    assert 'towel = towel.cli:main' in z.read('code_towel-1.772.dist-info/entry_points.txt').decode()
    assert not any('/tests/' in name or name.startswith('tests/') for name in z.namelist())
with tarfile.open(sdist) as archive:
    contents = {member.name.removeprefix('code_towel-1.772/'): archive.extractfile(member).read() for member in archive.getmembers() if member.isfile()}
    assert all(contents['src/' + name] == data for name, data in expected.items())
    for name in ('README.md','LICENSE','pyproject.toml','docs/DECISIONS.md','docs/KNOWN_LIMITATIONS.md'):
        assert contents[name] == (source / name).read_bytes(), name
result = {'commit': subprocess.check_output(['git','-C',str(source),'rev-parse','HEAD'],text=True).strip(), 'python_files': len(expected), 'artifacts': {str(path.relative_to(root)): {'sha256':hashlib.sha256(path.read_bytes()).hexdigest(), 'bytes':path.stat().st_size} for path in (wheel,sdist)}, 'status':'passed', 'publication_status':'local validation artifacts, package version still 1.772; not for upload'}
(root / 'artifacts.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2), flush=True)
