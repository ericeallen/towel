from pathlib import Path
import json,hashlib,subprocess
root=Path('/work/invoke');ready=Path('/work/invoke-ready');files=list((root/'invoke').rglob('*.py'));copies=sorted(root.glob('tests/_support/configs/**/invoke.py'));out=Path('/work/invoke-out')
print(json.dumps({'ambiguous_test_modules':[{'path':str(p.relative_to(root)),'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in copies],'runtime_python_files':len(files),'all_runtime_bytes_unchanged':all(p.read_bytes()==(ready/p.relative_to(root)).read_bytes() for p in files),'output_files':[str(p.relative_to(out)) for p in out.rglob('*') if p.is_file()] if out.exists() else [],'original_invoke_commit':subprocess.check_output(['git','-C',str(root),'rev-parse','HEAD'],text=True).strip()},indent=2))
