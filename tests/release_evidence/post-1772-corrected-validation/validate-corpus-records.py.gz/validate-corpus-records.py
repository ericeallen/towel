"""Reconcile a completed corpus with its manifest, console, and per-project files.

This checks completeness and evidence identity, not semantic acceptance. Every
nonaccepted outcome, typed fallback, and known failure still needs review.
Do not run against a partial report or reuse the interrupted predecessor's data.
"""
from collections import Counter
from datetime import datetime
from pathlib import Path
import hashlib
import json
import re
import tomllib

ROOT = Path(__file__).resolve().parent


def read(name):
    return json.loads((ROOT / name).read_text())


source = read("source.json")
summary = read("corpus-report/summary.json")
manifest_bytes = (ROOT / "candidate/scripts/ecosystem/manifest.toml").read_bytes()
projects = tomllib.loads(manifest_bytes.decode())["project"]
manifest = {project["name"]: project for project in projects}
rows = summary["results"]
assert len(rows) == len({row["name"] for row in rows}) == len(projects) == 141
assert {row["name"] for row in rows} == set(manifest)
assert summary["towel"] == source["commit"]
assert summary["typing_mode"] == "default"
artifacts = read("artifacts.json")
wheel = artifacts["artifacts"]["dist/code_towel-1.772-py3-none-any.whl"]
assert artifacts["commit"] == source["commit"]
assert summary["candidate"]["sha256"] == wheel["sha256"]
assert hashlib.sha256((ROOT / "dist/code_towel-1.772-py3-none-any.whl").read_bytes()).hexdigest() == wheel["sha256"]
counts = dict(Counter(row["verdict"] for row in rows))
assert summary["counts"] == counts
console = re.findall(
    r"^([A-Z_]+)\s+([\w.-]+)\s+files=(\d+)\s+refactor=\s*([\d.]+)s(.*)$",
    (ROOT / "corpus.log").read_text(), re.MULTILINE,
)
assert len(console) == len({row[1] for row in console}) == 141
assert {row[1]: row[0] for row in console} == {row["name"]: row["verdict"] for row in rows}
logs = {}
for row in rows:
    name = row["name"]
    assert read(f"corpus-report/{name}.json") == row
    pinned = manifest[name]["rev"]
    if pinned != "HEAD":
        assert row["commit"] == pinned, (name, pinned, row["commit"])
    assert re.fullmatch(r"[0-9a-f]{40}", row["commit"]), name
    cross = row["cross_module"]
    if cross is not None:
        assert cross["requested"] == manifest[name].get("cross_module", True), name
    for phase in ("baseline", "refactor", "after"):
        step = row[phase]
        if step is None:
            continue
        path = Path(step["log"])
        assert path.parent == Path("/work/logs"), (name, phase, path)
        relative = "corpus-logs/" + path.name
        data = (ROOT / relative).read_bytes()
        logs[relative] = {"bytes": len(data), "sha256": hashlib.sha256(data).hexdigest()}
    if row["verdict"] == "BROKEN_KNOWN":
        assert manifest[name].get("expect_broken") == row["detail"]
        assert manifest[name].get("known_failures"), name
nonaccepted = {row["name"]: row["verdict"] for row in rows if row["verdict"] not in {"PASS", "NO_CHANGE", "BROKEN_KNOWN"}}
exit_record = read("corpus-exit.json")
assert exit_record['oom_killed'] is False, 'Resource-killed validation is incomplete.'
assert exit_record["status"] == int(bool(nonaccepted))
launch = read("corpus-command.json")
args = launch["args"]
assert args[args.index("--network") + 1] == "none"
assert launch["commit"] == source["commit"]
assert launch['project_workers'] == 1
environment = read("corpus-environment.json")
assert environment["manifest_sha256"] == hashlib.sha256(manifest_bytes).hexdigest()
assert environment["network"] == "none"
elapsed = (datetime.fromisoformat(exit_record["finished"]) - datetime.fromisoformat(launch["started"])).total_seconds()
assert elapsed > 0
result = {
    "commit": source["commit"],
    "manifest_sha256": hashlib.sha256(manifest_bytes).hexdigest(),
    "projects": len(rows), "counts": counts, "corpus_exit_status": exit_record["status"],
    "driver_wall_seconds": elapsed,
    "nonaccepted": nonaccepted,
    "fallbacks": {row["name"]: row["fallback"] for row in rows if row["fallback"]},
    "known_failures": {row["name"]: row["detail"] for row in rows if row["verdict"] == "BROKEN_KNOWN"},
    "baseline_nonzero": {row["name"]: row["baseline"] for row in rows if row["baseline"] and row["baseline"]["returncode"]},
    "changed_files": sum(row["changed_files"] for row in rows),
    "towel_main_commit": next(row["commit"] for row in rows if row["name"] == "towel-main"),
    "raw_phase_logs": logs,
    "limit": "Structural reconciliation only; outcomes and fallback causes need separate review. Timing is the driver interval, not summed phase time or a performance comparison.",
}
(ROOT / "corpus-reconciliation.json").write_text(json.dumps(result, indent=2, sort_keys=True) + "\n")
print(json.dumps({key: value for key, value in result.items() if key != "raw_phase_logs"}, indent=2))
