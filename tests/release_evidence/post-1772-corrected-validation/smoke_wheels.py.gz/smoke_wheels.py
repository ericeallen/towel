from __future__ import annotations
import ast
from concurrent.futures import ThreadPoolExecutor
import hashlib
import json
import os
from pathlib import Path
import subprocess
import shutil
import time

ROOT = Path(__file__).resolve().parent
WHEEL = ROOT / 'dist/code_towel-1.772-py3-none-any.whl'
INTERPRETERS = {'3.11':'/opt/homebrew/bin/python3.11', '3.12':'/opt/homebrew/bin/python3.12', '3.13':'/opt/homebrew/bin/python3.13'}
UV = str(Path(shutil.which('uv')).resolve())
SOURCE = '''def first(value: int) -> int:
    total = value * 2
    result = total + 3
    return result

def second(value: int) -> int:
    total = value * 2
    result = total + 4
    return result

if __name__ == "__main__":
    print(first(5), second(7))
'''

def smoke(case):
    version, extras = case
    start = time.monotonic()
    root = ROOT / 'wheel-smoke' / (version + ('-extras' if extras else '-bare'))
    root.mkdir(parents=True)
    work = root / 'work'
    work.mkdir()
    env = {key:value for key,value in os.environ.items() if key not in ('PYTHONPATH','VIRTUAL_ENV','COVERAGE_RCFILE','COVERAGE_PROCESS_START','PYTHONHOME')}
    env.update(UV_CACHE_DIR='/private/tmp/towel-post-1772-uv-cache', PYTHONNOUSERSITE='1', TOWEL_WORKERS='1')
    commands=[]
    def run(args, *, input=None):
        completed=subprocess.run([str(arg) for arg in args], cwd=work, env=env, input=input, text=True, capture_output=True, timeout=180)
        commands.append({'args':[str(arg) for arg in args],'status':completed.returncode,'stdout':completed.stdout,'stderr':completed.stderr})
        (root/'commands.json').write_text(json.dumps(commands,indent=2)+'\n')
        if completed.returncode:
            raise AssertionError((version,extras,args,completed.stderr))
        return completed
    print('START', version, 'extras' if extras else 'bare', flush=True)
    venv=root/'venv'
    run([UV,'venv','--python',INTERPRETERS[version],venv])
    python=venv/'bin/python'
    env['PATH']=str(venv/'bin')+':/usr/bin:/bin'
    run([UV,'pip','install','--python',python,str(WHEEL)+('[format,types]' if extras else '')])
    installed=json.loads(run([python,'-I','-c','import json,sys,platform,towel,importlib.metadata as m; print(json.dumps({"source":towel.__file__,"python":sys.version,"platform":platform.platform(),"distributions":{d.metadata["Name"]:d.version for d in m.distributions()}}))']).stdout)
    assert str(venv) in installed['source'] and '/site-packages/' in installed['source']
    assert installed['distributions']['code-towel']=='1.772'
    program=work/'program.py'; program.write_text(SOURCE)
    config='[project]\nname="wheel-probe"\nversion="0"\n'
    if extras:
        config+='[tool.mypy]\nstrict=true\n[tool.black]\nline-length=88\n'
    (work/'pyproject.toml').write_text(config)
    if extras:
        run([python,'-m','black',program])
    original=program.read_text()
    baseline=run([python,program]).stdout
    cli=venv/'bin/towel'
    run([cli,'--version'])
    preview=run([cli,'preview',program,'--progress','none'])
    assert 'Would apply 1 refactoring(s)' in preview.stdout, preview.stdout
    assert program.read_text()==original
    # Capture the default confirmation path too; no third-party program is run here.
    interactive=run([cli,'dry',program,work/'declined.py','--progress','none'],input='n\n')
    assert not (work/'declined.py').exists()
    output=work/'output.py'
    dry=run([cli,'dry',program,output,'--no-interactive','--progress','detail'])
    assert 'Applied 1 refactoring(s)' in dry.stdout, dry.stdout
    assert run([python,output]).stdout==baseline
    helpers=[n for n in ast.parse(output.read_text()).body if isinstance(n,ast.FunctionDef) and n.name.startswith('__extracted_func')]
    assert len(helpers)==1
    if extras:
        assert helpers[0].returns is not None and all(arg.annotation is not None for arg in helpers[0].args.args)
        run([python,'-P','-m','mypy','--strict',output])
        run([python,'-m','black','--check',output])
        env['TOWEL_SMOKE_COLD_RECORD']=str(root/'cold-check.json')
        run([python,'-I',ROOT/'observe_cold_cli.py','dry',program,work/'cold-output.py','--no-interactive','--progress','none'])
        cold=json.loads((root/'cold-check.json').read_text())
        assert cold['resets'] and cold['source']==installed['source'], cold
        assert run([python,work/'cold-output.py']).stdout==baseline
    else:
        assert not {'mypy','pyright','black'} & set(installed['distributions'])
        assert 'not inferred or verified' in dry.stdout, dry.stdout
        assert 'not installed' in (dry.stdout+dry.stderr).lower(), 'Missing-tools note absent'
    run([python,'-I',ROOT/'candidate/scripts/audit_dependencies.py'])
    (root/'dependencies.txt').write_text(commands[-1]['stdout'])
    result={'case':version+('-extras' if extras else '-bare'),'status':'passed','elapsed_seconds':time.monotonic()-start,'installed':installed,'wheel_sha256':hashlib.sha256(WHEEL.read_bytes()).hexdigest()}
    (root/'result.json').write_text(json.dumps(result,indent=2)+'\n')
    print('END',result['case'],round(result['elapsed_seconds'],2),'passed',flush=True)
    return result

if __name__=='__main__':
    cases=[(v,extras) for v in INTERPRETERS for extras in (False, True)]
    with ThreadPoolExecutor(max_workers=2) as pool:
        results=list(pool.map(smoke,cases))
    (ROOT/'wheel-smoke/results.json').write_text(json.dumps(results,indent=2)+'\n')
