"""Preserve the interrupted predecessor's records before a fresh offline corpus."""
from pathlib import Path
import os
import sys

work = Path('/work')
previous = work / 'interrupted-3f09421'
assert not previous.exists(), previous
previous.mkdir()
for name in ('report', 'logs'):
    old = work / name
    assert old.is_dir(), old
    old.rename(previous / name)
print('Preserved predecessor report/logs in', previous, flush=True)
os.execv(sys.executable, [
    sys.executable, '-u', '/snapshot/scripts/ecosystem_check.py', '--run-untrusted-code',
    '--towel-src', '/snapshot/src', '--towel-wheel',
    '/candidate-wheel/code_towel-1.772-py3-none-any.whl', '--work', '/work',
    '--workers', '2', '--timeout', '10800',
])
