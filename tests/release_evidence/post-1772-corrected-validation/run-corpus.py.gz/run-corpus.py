from pathlib import Path
import subprocess
import json
import datetime
import threading
import hashlib

root = Path(__file__).resolve().parent
commit = subprocess.check_output(['git','-C',str(root/'candidate'),'rev-parse','HEAD'],text=True).strip()
source = json.loads((root/'source.json').read_text())
assert source['commit'] == commit
predecessor = json.loads((root.parent/'revised-gates/corpus-report/summary.json').read_text())
assert predecessor['towel'] == 'acb176a9a48a40882dc9f0d4ff3a9841f959fd86'
assert len(predecessor['results']) == 141
review = json.loads((root/'predecessor-review.json').read_text())
assert review['reviewed_commit'] == predecessor['towel']
assert review['unresolved_source_findings'] == []
assert review['infrastructure_mitigations']['towel-main']['project_workers'] == 1
replay = json.loads((root.parent/'annotation-gates/tornado-replay/result.json').read_text())
assert replay['matches_baseline'] and replay['runtime_tree'] == source['runtime_tree']
steps = json.loads((root/'build-results.json').read_text())
assert len(steps) == 5 and all(step['exit_status']==0 for step in steps)
for name in ('towel-next-public-deps','towel-next-corpus-3f09421','towel-next-corpus-acb176a','towel-next-tornado-a2e6734-r2'):
    assert not json.loads(subprocess.check_output(['docker','inspect',name],text=True))[0]['State']['Running']
args = ['docker','run','-d','--name','towel-next-corpus-'+commit[:7],'--init','--network','none',
        '-e','UV_OFFLINE=1','-e','TOWEL_WORKERS=1','-e','UV_CACHE_DIR=/work/.uv-cache',
        '-e','UV_FIND_LINKS=/public-wheels',
        '-v',str(root.parent/'revised-gates/corpus-review/blinker/public-wheels')+':/public-wheels:ro',
        '-v',str(root.parent/'revised-gates/corpus-review/chardet/public-data')+':/public-chardet-data:ro',
        '-v',str(root.parent/'revised-gates/corpus-review/chardet/public-data-provenance.json')+':/public-chardet-provenance.json:ro',
        '-v',str(root/'candidate')+':/snapshot:ro','-v',str(root/'dist')+':/candidate-wheel:ro',
        '-v',str(root/'corpus-entry.py')+':/run-corpus.py:ro',
        '-v','towel-next-offline-deps-20260927:/work','-w','/snapshot',
        'towel-next-matrix:procps-20260927','python','-u','/run-corpus.py']
started = datetime.datetime.now(datetime.timezone.utc).isoformat()
container = subprocess.check_output(args,text=True).strip()
(root/'corpus-command.json').write_text(json.dumps({'args':args,'container':container,'started':started,
    'commit':commit,'project_workers':1,'gate_order':'Corrected corpus follows reviewed predecessor and successful Tornado replay; one project at a time avoids the observed Sphinx/Towel-baseline memory overlap. Final matrix remains required.'},indent=2)+'\n')
print('START corpus',commit,started,flush=True)
inspection = json.loads(subprocess.check_output(['docker','inspect',container],text=True))[0]
assert inspection['HostConfig']['NetworkMode'] == 'none'
assert inspection['Image'] == 'sha256:47fe32ba90ea4d65f85dd24fb3a93f754e8e3fa922a58930f88e8e0461b6d6d8'
runtime = json.loads(subprocess.check_output(['docker','exec',container,'python','-c','import json,platform,sys; print(json.dumps({"python":sys.version,"platform":platform.platform()}))'],text=True))
environment = {'recorded':datetime.datetime.now(datetime.timezone.utc).isoformat(), 'container':inspection['Name'].lstrip('/'), 'image_digest':inspection['Image'], 'network':'none', 'runtime':runtime, 'mounts':[{'source':item['Source'],'destination':item['Destination'],'read_write':item['RW']} for item in inspection['Mounts']], 'launcher_sha256':{name:hashlib.sha256((root/name).read_bytes()).hexdigest() for name in ('corpus-entry.py','run-corpus.py')}, 'manifest_sha256':hashlib.sha256((root/'candidate/scripts/ecosystem/manifest.toml').read_bytes()).hexdigest(), 'public_dependency_wheels':{p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in (root.parent/'revised-gates/corpus-review/blinker/public-wheels').glob('*.whl')}, 'public_dependency_selection':'UV_FIND_LINKS=/public-wheels; offline, read-only wheel mount; Blinker versions pinned by frozen manifest'}
data_provenance = root.parent/'revised-gates/corpus-review/chardet/public-data-provenance.json'
data_record = json.loads(data_provenance.read_text())
environment['chardet_accuracy_data'] = {'commit':data_record['commit'],'files':data_record['file_count'],'bytes':data_record['bytes'],'provenance_sha256':hashlib.sha256(data_provenance.read_bytes()).hexdigest()}
(root/'corpus-environment.json').write_text(json.dumps(environment,indent=2)+'\n')
done = threading.Event()
def sample():
    with (root/'corpus-resources.jsonl').open('w') as record:
        while not done.is_set():
            result = subprocess.run(['docker','stats','--no-stream','--format','{{json .}}',container],text=True,capture_output=True)
            record.write(json.dumps({'time':datetime.datetime.now(datetime.timezone.utc).isoformat(),'status':result.returncode,'docker_stats':result.stdout.strip(),'error':result.stderr.strip()})+'\n')
            record.flush()
            done.wait(15)
sampler=threading.Thread(target=sample); sampler.start()
with (root/'corpus.log').open('w') as log:
    follower=subprocess.Popen(['docker','logs','--follow',container],stdout=log,stderr=subprocess.STDOUT)
    status=int(subprocess.check_output(['docker','wait',container],text=True).strip()); follower.wait()
done.set(); sampler.join()
final_state = json.loads(subprocess.check_output(['docker','inspect','--format','{{json .State}}',container],text=True))
(root/'corpus-container-state.json').write_text(json.dumps(final_state,indent=2)+'\n')
(root/'corpus-exit.json').write_text(json.dumps({'status':status,'finished':datetime.datetime.now(datetime.timezone.utc).isoformat(),'oom_killed':final_state['OOMKilled']},indent=2)+'\n')
subprocess.run(['docker','cp',container+':/work/report',str(root/'corpus-report')],check=True)
subprocess.run(['docker','cp',container+':/work/logs',str(root/'corpus-logs')],check=True)
print('END corpus',status,flush=True)
raise SystemExit(status)
