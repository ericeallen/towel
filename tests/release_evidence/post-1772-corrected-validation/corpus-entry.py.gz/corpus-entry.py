"""Preserve the completed predecessor's records before a fresh offline corpus."""
from pathlib import Path
import json
import os
import sys
import hashlib
import shutil

work = Path('/work')
summary = json.loads((work/'report/summary.json').read_text())
assert summary['towel'] == 'acb176a9a48a40882dc9f0d4ff3a9841f959fd86'
assert len(summary['results']) == 141
previous = work / 'completed-acb176a'
assert not previous.exists(), previous
previous.mkdir()
for name in ('report', 'logs'):
    old = work / name
    assert old.is_dir(), old
    old.rename(previous / name)
print('Preserved predecessor report/logs in', previous, flush=True)
# The upstream dev checkout requests this public accuracy corpus at collection.
# Supply its recorded exact bytes before disabling any need for a download.
data = work/'chardet/tests/data'
assert not data.exists(), 'Unexpected existing dataset: inspect instead of overwriting.'
provenance = json.loads(Path('/public-chardet-provenance.json').read_text())
assert provenance['commit'] == 'b0c0d206913ba118ffea2f7d306883e7a4a76db7'
assert provenance['project_commit'] == 'e9603fad69cdc5d34d03616682650acd4891eb5d'
shutil.copytree('/public-chardet-data', data)
for relative, item in provenance['files'].items():
    assert hashlib.sha256((data/relative).read_bytes()).hexdigest() == item['sha256']
assert len([p for p in data.rglob('*') if p.is_file()]) == provenance['file_count'] == 3163
(data/'.test-data-ref').write_text('main\n')
print('Verified offline Chardet accuracy data:',provenance['commit'],provenance['file_count'],'files',flush=True)
os.execv(sys.executable, [
    sys.executable, '-u', '/snapshot/scripts/ecosystem_check.py', '--run-untrusted-code',
    '--towel-src', '/snapshot/src', '--towel-wheel',
    '/candidate-wheel/code_towel-1.772-py3-none-any.whl', '--work', '/work',
    '--workers', '1', '--timeout', '10800',
])
