"""Resume after explicit review of the completed, nonzero Towel baseline.

The initial queue stop and corpus records remain intact. Completion without
OOM is established; the baseline's 18 failures are never relabelled green.
This launches only the still-unrun serial matrix and makes no release claim.
"""
from datetime import datetime, timezone
from pathlib import Path
import hashlib
import json
import subprocess

ROOT = Path(__file__).resolve().parent


def now():
    return datetime.now(timezone.utc).isoformat()


def read(name):
    return json.loads((ROOT / name).read_text())


def run():
    result = read('corpus-reconciliation.json')
    assert result['projects'] == 141
    assert result['counts'] == {'PASS': 98, 'NO_CHANGE': 37, 'BROKEN_KNOWN': 1, 'CRASH': 5}
    assert set(result['nonaccepted']) == {'isort', 'invoke', 'towel-v1.414', 'towel-v1.618', 'towel-main'}
    assert set(result['fallbacks']) == {'trio', 'typing_extensions', 'cheroot'}
    assert set(result['known_failures']) == {'pyparsing'}
    assert read('corpus-exit.json')['oom_killed'] is False
    assert len(read('completed-baseline-review.json')['complete_baselines']) == 141
    assessment = read('corpus-review/towel-main/assessment.json')
    assert assessment['towel_commit'] == result['commit']
    assert assessment['baseline_completed'] and assessment['baseline_exit'] == 1
    assert len(assessment['failures']) == 18
    integrity = read('refusal-integrity.json')
    for name in result['nonaccepted']:
        row = read(f'corpus-report/{name}.json')
        assert row['verdict'] == 'CRASH' and row['changed_files'] == 0 and row['after'] is None
        assert row['refactor']['returncode'] == 1
        assert integrity[name]['input_bytes_unchanged'] and not integrity[name]['output_files']
    for name, expected in [('tornado', 'PASS'), ('chardet', 'PASS'), ('sphinx', 'PASS'), ('blinker', 'NO_CHANGE')]:
        row = read(f'corpus-report/{name}.json')
        assert row['verdict'] == expected and row['typing_mode'] == 'default' and not row['fallback']
    review = {
        'recorded': now(), 'commit': result['commit'], 'projects': 141,
        'nonaccepted': result['nonaccepted'], 'fallbacks': result['fallbacks'],
        'known_failures': result['known_failures'], 'corpus_oom_killed': False,
        'towel_main_baseline_completed': read('corpus-report/towel-main.json')['baseline'],
        'towel_main_review_sha256': hashlib.sha256((ROOT / 'corpus-review/towel-main/assessment.json').read_bytes()).hexdigest(),
        'matrix_authorized_to_run': True,
        'scope': 'Completed baseline and explicit failure review permit the independent current-source matrix. No nonzero result is relabelled passed; final corpus acceptance remains separate.',
    }
    assert not (ROOT / 'mechanical-corpus-review.json').exists()
    (ROOT / 'mechanical-corpus-review.json').write_text(json.dumps(review, indent=2) + '\n')
    assert not (ROOT / 'matrix-driver.log').exists()
    print(now(), 'Starting still-unrun serial matrix after reviewed corpus stop.', flush=True)
    with (ROOT / 'matrix-driver.log').open('w') as log:
        subprocess.run(['python3', '-u', str(ROOT / 'run-matrix.py')], cwd=ROOT, stdout=log, stderr=subprocess.STDOUT, check=True)
    for version in ('3.11', '3.13', '3.12'):
        row = read(f'matrix-{version}-result.json')
        assert row['exit_status'] == 0 and row['commit'] == result['commit']
        state = read(f'matrix-{version}-container.json')[0]['State']
        assert not state['Running'] and not state['OOMKilled'] and state['ExitCode'] == 0


try:
    run()
except BaseException as error:
    (ROOT / 'continuation-result.json').write_text(json.dumps({'finished': now(), 'status': 'stopped_for_review', 'resumed_after': 'continuation-stopped-20260928.json', 'error': repr(error)}, indent=2) + '\n')
    raise
else:
    (ROOT / 'continuation-result.json').write_text(json.dumps({'finished': now(), 'status': 'mechanical_gates_complete', 'resumed_after': 'continuation-stopped-20260928.json', 'final_acceptance': False}, indent=2) + '\n')
    print(now(), 'Serial matrix completed; evidence integration/review still required.', flush=True)
