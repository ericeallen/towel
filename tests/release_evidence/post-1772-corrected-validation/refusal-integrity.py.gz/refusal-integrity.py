from pathlib import Path
import hashlib,json
packages={'isort': 'isort', 'invoke': 'invoke', 'towel-v1.414': 'src/towel', 'towel-v1.618': 'src/towel', 'towel-main': 'src/towel'}
rows={}
for name,package in packages.items():
 original=Path('/work')/name/package
 ready=Path('/work')/(name+'-ready')/package
 def hashes(root):
  return {str(p.relative_to(root)):hashlib.sha256(p.read_bytes()).hexdigest() for p in root.rglob('*.py') if '__pycache__' not in p.parts}
 before,after=hashes(original),hashes(ready)
 assert before and before==after,(name,len(before),len(after))
 out=Path('/work')/(name+'-out')
 outputs=[str(p.relative_to(out)) for p in out.rglob('*') if p.is_file()]
 assert not outputs,(name,outputs)
 rows[name]={'runtime_python_files':len(before),'runtime_sha256':before,'input_bytes_unchanged':True,'output_files':outputs}
print(json.dumps(rows,indent=2))
