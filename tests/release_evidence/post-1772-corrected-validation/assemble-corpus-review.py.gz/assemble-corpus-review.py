"""Bind explicit reviewed corpus exceptions to completed current raw evidence."""
from pathlib import Path
from datetime import datetime, timezone
import json, sys, tomllib
REPO=Path('/Users/ericeallen/Code/towel-post-1772')
sys.path.insert(0,str(REPO))
from scripts import verify_release_evidence as gate
C=Path(__file__).resolve().parent
read=lambda name:json.loads((C/name).read_text())
source=read('source.json');reconciliation=read('corpus-reconciliation.json')
rows={row['name']:row for row in read('corpus-report/summary.json')['results']}
manifest={p['name']:p for p in tomllib.loads((C/'candidate/scripts/ecosystem/manifest.toml').read_text())['project']}
files={str(p.relative_to(C)):gate.FileRef(str(p.relative_to(C)),gate.digest(p.read_bytes())) for p in (C/'corpus-logs').iterdir() if p.is_file()}
records=gate.Records(C,files)
result={'commit':source['commit'],'reviewed':datetime.now(timezone.utc).isoformat(),'reviewer':'Codex root','open_source_findings':[],'scope':'Explicit review within declared semantics and recorded environments, not all-green upstream CI or complete typed coverage. Existing Cheroot own-hook discovery limitation remains an explicitly scoped deferred integration gap. No new unreviewed source defect remains from this corpus.'}
for category,names in [('reviewed_nonaccepted',reconciliation['nonaccepted']),('reviewed_fallbacks',reconciliation['fallbacks']),('reviewed_known_failures',reconciliation['known_failures'])]:
 result[category]={}
 for name in names:
  review=read(f'corpus-review/{name}/assessment.json')
  reason=review.get('reason') or review.get('cause') or review.get('classification')
  evidence=[str(p.relative_to(C)) for p in sorted((C/f'corpus-review/{name}').rglob('*')) if p.is_file()]
  if category=='reviewed_nonaccepted':evidence+=['refusal-integrity.json','refusal-integrity-command.json','refusal-integrity.py']
  if name in ('typing_extensions','cheroot'):evidence+=['fallback-config-probe.py','fallback-config-probe-command.json','fallback-config-probe-result.json']
  result[category][name]={'reason':reason,'evidence_files':sorted(evidence)}
result['reviewed_baseline_failures']={}
for name in reconciliation['baseline_nonzero']:
 row=rows[name];before,failed=gate.phase_outcome(records,row['baseline'],manifest[name]);assert before.returncode and failed
 evidence=[f'corpus-report/{name}.json','completed-baseline-review.json',f"corpus-logs/{Path(row['baseline']['log']).name}"]
 reason=f"Completed original-source baseline: {before.summary}. Its exact {len(failed)} failure/error identities are retained; this is not an all-green upstream suite. "
 if row['verdict']=='PASS':
  gate.verify_pass(records,row,manifest[name]);after,other=gate.phase_outcome(records,row['after'],manifest[name])
  evidence.append(f"corpus-logs/{Path(row['after']['log']).name}")
  if (before,failed)==(after,other):reason+='Complete transformed suite retained the same outcome, collected count and failure identities.'
  else:
   reason+='Initial differences were reconciled by equal isolated and full-suite before/after retests; all retest outcomes were independently parsed.'
   evidence += [str(p.relative_to(C)) for p in (C/'corpus-logs').glob(name+'-*retest*')]
 elif row['verdict']=='NO_CHANGE':
  assert row['changed_files']==0;reason+='No transformed files; no new after suite is claimed.'
 elif row['verdict']=='CRASH':
  assert row['changed_files']==0 and row['after'] is None
  reason+='Conservative import-origin refusal before any edits; no transformed suite is claimed. '+read(f'corpus-review/{name}/assessment.json').get('reason','')
  evidence+=result['reviewed_nonaccepted'][name]['evidence_files']
 else:raise AssertionError((name,row['verdict']))
 result['reviewed_baseline_failures'][name]={'reason':reason,'failed_test_ids':sorted(failed),'evidence_files':sorted(set(evidence))}
result['reviewed_repairs']={name:{'reason':read(f'corpus-review/{name}/assessment.json').get('reason',read(f'corpus-review/{name}/assessment.json').get('classification','')),'evidence_files':[str(p.relative_to(C)) for p in sorted((C/f'corpus-review/{name}').rglob('*')) if p.is_file()]} for name in ('chardet','blinker','sphinx','tornado')}
assert len(result['reviewed_baseline_failures'])==33
for category,value in result.items():
 if category.startswith('reviewed_'):
  for detail in value.values():
   assert detail['reason']
   assert all((C/f).is_file() for f in detail['evidence_files'])
(C/'corpus-assessment.json').write_text(json.dumps(result,indent=2)+'\n')
print({name:len(value) for name,value in result.items() if name.startswith('reviewed_')})
