from pathlib import Path
import datetime
import hashlib
import json
import os
import shutil
import subprocess
import time

root = Path(__file__).resolve().parent
project = root / 'selfdogfood/project'
candidate = root / 'candidate'
commit = subprocess.check_output(['git', '-C', str(candidate), 'rev-parse', 'HEAD'], text=True).strip()
assert not project.exists(), project
subprocess.run(['git', 'clone', '--no-hardlinks', '--no-checkout', str(candidate), str(project)], check=True)
subprocess.run(['git', '-C', str(project), 'checkout', '--detach', commit], check=True)
paths = subprocess.check_output(['git', '-C', str(candidate), 'ls-files', 'src/towel'], text=True).splitlines()
records = []
for path in paths:
    target = project / path
    source = root / 'selfdogfood/generated' / Path(path).relative_to('src/towel')
    assert source.is_file(), source
    before = hashlib.sha256(target.read_bytes()).hexdigest()
    shutil.copyfile(source, target)
    records.append({'path': path, 'before': before, 'after': hashlib.sha256(target.read_bytes()).hexdigest()})
manifest = {'input_commit': commit, 'runtime_files': records, 'changed_files': sum(r['before'] != r['after'] for r in records)}
(root / 'selfdogfood/source.json').write_text(json.dumps(manifest, indent=2) + '\n')
env = {**os.environ, 'UV_CACHE_DIR': '/private/tmp/towel-post-1772-uv-cache', 'UV_OFFLINE': '1'}
steps = [
 ('sync', ['uv', 'sync', '--python', '/opt/homebrew/bin/python3.13', '--frozen', '--extra', 'dev']),
 ('imported-source', ['uv', 'run', '--frozen', 'python', '-c', "from pathlib import Path; import sys,towel; p=Path(towel.__file__).resolve(); print(sys.version); print(p); assert p.is_relative_to(Path.cwd()/'src')"]),
 ('typecheck', ['uv', 'run', '--frozen', 'mypy']),
 ('tests', ['uv', 'run', '--frozen', 'pytest', '-q', '--durations=20']),
]
results = []
for name, command in steps:
    started = datetime.datetime.now(datetime.timezone.utc).isoformat()
    clock = time.monotonic()
    print('START', name, started, flush=True)
    with (root / f'selfdogfood/{name}.log').open('w') as log:
        result = subprocess.run(command, cwd=project, env=env, stdout=log, stderr=subprocess.STDOUT)
    record = {'name': name, 'command': command, 'started': started, 'finished': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'seconds': time.monotonic() - clock, 'exit_status': result.returncode}
    results.append(record)
    (root / 'selfdogfood/results.json').write_text(json.dumps({'input_commit': commit, 'results': results}, indent=2) + '\n')
    print('END', name, result.returncode, record['seconds'], flush=True)
    if result.returncode:
        raise SystemExit(result.returncode)
