from pathlib import Path
import datetime
import json
import os
import subprocess
import time

root = Path(__file__).resolve().parent
env = {**os.environ, 'UV_CACHE_DIR':'/private/tmp/towel-post-1772-uv-cache', 'UV_OFFLINE':'1'}
records = []
for family, seed in (('grammar',1790541100),('scope',1790543100)):
    args=['uv','run','--frozen','python','-m','tests.differential.fuzz','--count','2000','--seed',str(seed),'--jobs','4','--family',family,'--out',str(root/('fuzz-'+family))]
    started=datetime.datetime.now(datetime.timezone.utc).isoformat(); clock=time.monotonic()
    print('START',family,started,flush=True)
    with (root/('fuzz-'+family+'.log')).open('w') as log:
        result=subprocess.run(args,cwd=root/'candidate',env=env,stdout=log,stderr=subprocess.STDOUT)
    records.append({'family':family,'args':args,'started':started,'finished':datetime.datetime.now(datetime.timezone.utc).isoformat(),'seconds':time.monotonic()-clock,'exit_status':result.returncode})
    (root/'fuzz-results.json').write_text(json.dumps(records,indent=2)+'\n')
    print('END',family,result.returncode,flush=True)
    if result.returncode:raise SystemExit(result.returncode)
