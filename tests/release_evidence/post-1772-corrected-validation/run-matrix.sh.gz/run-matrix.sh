#!/bin/bash
set -euo pipefail
version="$1"
export UV_CACHE_DIR=/work/uv-cache
export UV_PYTHON_INSTALL_DIR=/work/python
export UV_LINK_MODE=hardlink
export PYTHONUNBUFFERED=1
unset PYTHONDONTWRITEBYTECODE PYTEST_ADDOPTS COVERAGE_RCFILE COVERAGE_PROCESS_START PYTHONPATH
cd "/work/py$version"
started="$(date -u +%Y-%m-%dT%H:%M:%SZ)"
function finish {
    result=$?
    .venv/bin/python - "$version" "$started" "$result" <<'PY'
import datetime,json,platform,subprocess,sys,importlib.metadata
from pathlib import Path
version,started,result=sys.argv[1:]
data={'python_job':version,'started':started,'finished':datetime.datetime.now(datetime.timezone.utc).isoformat(),'exit_status':int(result),'python':sys.version,'platform':platform.platform(),'commit':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'runtime_tree':subprocess.check_output(['git','rev-parse','HEAD:src/towel'],text=True).strip(),'tools':{name:importlib.metadata.version(name) for name in ('mypy','pyright','pytest','coverage')},'flags':{'UV_LINK_MODE':'hardlink','bytecode':'on','coverage':'run -m pytest -q --durations=20; combine; report --fail-under=85'}}
Path('/evidence/matrix-'+version+'-result.json').write_text(json.dumps(data,indent=2)+'\n')
print(json.dumps(data),flush=True)
PY
    exit "$result"
}
trap finish EXIT
git -c safe.directory=/candidate fetch --update-shallow /candidate +HEAD:refs/towel-validation/candidate
git checkout --detach refs/towel-validation/candidate
test "$(git rev-parse HEAD)" = "$(git -c safe.directory=/candidate -C /candidate rev-parse HEAD)"
uv sync --frozen --extra dev
.venv/bin/python -V
.venv/bin/python -c 'import towel; from pathlib import Path; actual=Path(towel.__file__).resolve(); expected=Path.cwd() / "src/towel/__init__.py"; print(actual); assert actual == expected, (actual, expected)'
command -v ps
ps -axo pid=,ppid= >/dev/null
uv run --frozen coverage erase
uv run --frozen coverage run -m pytest -q --durations=20
uv run --frozen coverage combine
uv run --frozen coverage report --fail-under=85
uv run --frozen coverage xml -o "/evidence/coverage-$version.xml"
cp .coverage "/evidence/coverage-$version.sqlite"
git diff --exit-code HEAD
