from pathlib import Path
import hashlib,json,importlib.util
original=Path('/work/isort/isort')
ready=Path('/work/isort-ready/isort')
a={str(p.relative_to(original)):hashlib.sha256(p.read_bytes()).hexdigest() for p in original.rglob('*.py')}
b={str(p.relative_to(ready)):hashlib.sha256(p.read_bytes()).hexdigest() for p in ready.rglob('*.py')}
assert a==b
out=Path('/work/isort-out')
assert not any(out.iterdir())
script=Path('/work/isort-ready/scripts/mkstdlibs.py').read_text()
assert 'from stdlibs import py38' in script
stdlibs=importlib.util.find_spec('stdlibs')
assert stdlibs is not None
print(json.dumps({'runtime_python_files':len(a),'input_bytes_unchanged':True,'input_sha256':a,'output_directory_empty':True,'stdlibs_origin':stdlibs.origin,'local_stdlibs_package':str(ready/'stdlibs'),'generator_import_line':next(line for line in script.splitlines() if line.startswith('from stdlibs import '))},indent=2))
