# Typed performance comparison

These experiments compare frozen source 35035a7 with 1b9719612ae9e844df8fbab2775c0646a0ab7ebf. The latter contains the bounded lexical-definition index, correlated-signature construction, caller-side narrowing guard, observed NotImplemented return handling, and grouped Pyright reveal requests. They are intermediate performance evidence, not final release validation.

## Sphinx initial reveal

The two frozen wheels ran sequentially in Docker image `towel-eco:29454ab`, using the same complete Sphinx 9.1.1 project and environment (Linux, CPython 3.12.14, mypy 1.19.1, Pyright 1.1.407), with network disabled and one Towel worker. The production command was stopped deliberately after initial reveal, before the fixed-point extraction run. See the two profile scripts and `sphinx-comparison.json` for commands, raw requests, responses and assertions.

Both runs issued 2,949 requests covering 7,391 expressions across 218 files. Their 7,387 reported types match exactly, including the four identically unanswered expression probes; neither reports a failed file. Before: 218 exchanges, 980.718 seconds in reveal. After: one exchange, 8.649 seconds in reveal. This is a measurement of that startup phase, not a whole-project speedup claim.

## Packaging full fixed point

Four production CLI runs used packaging 26.3, CPython 3.13.7, macOS 26.5.1 arm64, mypy 2.3.1 strict mode, one worker, same-file extraction and no formatter. They ran sequentially in baseline/candidate/candidate/baseline order after the Sphinx work had stopped. Each completed the final cold type check. Runtime suites were not included in these timing runs.

The baseline took 34.180 and 34.566 seconds; the candidate took 28.810 and 28.948 seconds, a 15.98% reduction in mean elapsed time. Baseline: 19 applications, 27 signature checks, 8 signature rejections. Candidate: 18 applications, 18 signature checks, no signature rejections. The one fewer application is intentional: a previously accepted `Any`-based extraction erased the caller's `None` relationship, which the new construction guard preserves. Both runs retained the same checker-coverage refusal, attempted twice. Generated Python files match byte-for-byte within each arm.

`packaging-comparison.json` records the assertions. Each run directory holds its measurement script, CLI log, proposal events, context and boundary records. The imported source paths identify the frozen snapshots. A raw `source.json` field named `annotation_wiring_sha256` actually hashes the Materialization source: that label is erroneous and must not be used to identify annotation_wiring. Use the archived source and commit identity instead. The raw evidence is retained unchanged.

The earlier `packaging-before` cProfile run is cause-analysis evidence only; its instrumented elapsed time is not comparable to the four unprofiled runs.
