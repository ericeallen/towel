"""Capture and time the production CLI's initial Pyright inference workload."""
import hashlib
import json
from collections import Counter
from dataclasses import asdict
from pathlib import Path
import sys
from threading import Event,Thread
from time import perf_counter
from unittest.mock import patch
import importlib.metadata

from towel.cli import main
from towel.type_inference import PyrightOracle
import towel

root=Path('/evidence/sphinx-after');root.mkdir(exist_ok=True)
start=perf_counter();finished=Event();spans=[]
original_reveal=PyrightOracle.reveal
original_diagnostics=PyrightOracle._probe_diagnostics

class Captured(Exception): pass

def diagnostics(self,project,sources):
    began=perf_counter()
    result=original_diagnostics(self,project,sources)
    span={'project':str(project),'files':len(sources),'sources':{path:hashlib.sha256(text.encode()).hexdigest() for path,text in sources.items()},'seconds':perf_counter()-began,'outcomes':dict(Counter(type(value).__name__ for value in result.values()))}
    spans.append(span)
    with (root/'spans.jsonl').open('a') as out: out.write(json.dumps(span)+'\n')
    print('BATCH',len(spans),len(sources),'files',round(span['seconds'],2),flush=True)
    return result

def reveal(self,requests):
    keys=Counter((r.file_path,hashlib.sha256(r.source.encode()).hexdigest(),r.line,r.indent,r.expressions) for r in requests)
    (root/'requests.json').write_text(json.dumps([asdict(r) for r in requests]))
    (root/'inputs.json').write_text(json.dumps({'requests':len(requests),'unique_requests':len(keys),'files':len({r.file_path for r in requests}),'expressions':sum(len(r.expressions) for r in requests),'python':sys.version,'towel':towel.__file__,'tools':{name:importlib.metadata.version(name) for name in ('code-towel','mypy','pyright','Sphinx')}} ,indent=2))
    began=perf_counter()
    result=original_reveal(self,requests)
    (root/'answers.json').write_text(json.dumps({'answers':[(key,value) for key,value in result.items()],'unanswered':dict(getattr(result,'unanswered',{}))},sort_keys=True))
    (root/'summary.json').write_text(json.dumps({'reveal_seconds':perf_counter()-began,'total_seconds':perf_counter()-start,'diagnostic_calls':len(spans),'unique_diagnostic_inputs':len({(path,digest) for s in spans for path,digest in s['sources'].items()})},indent=2))
    raise Captured

def heartbeat():
    while not finished.wait(30):print('PROFILE',round(perf_counter()-start), 'seconds',len(spans),'files completed',flush=True)

watcher=Thread(target=heartbeat,daemon=True);watcher.start()
sys.argv=['towel','dry','/work/sphinx-ready/sphinx','/work/sphinx-after-unused-output','--cross-module','--no-interactive','--no-format','--progress','detail']
try:
    with patch.object(PyrightOracle,'reveal',reveal),patch.object(PyrightOracle,'_probe_diagnostics',diagnostics):main()
except Captured:
    print('INITIAL PRODUCTION REVEAL COMPLETE',flush=True)
finally:
    finished.set();watcher.join()
