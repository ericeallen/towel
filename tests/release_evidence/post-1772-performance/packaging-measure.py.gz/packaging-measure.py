from __future__ import annotations

import json
import ast
import inspect
import hashlib
import towel
import sys
from collections import Counter
from pathlib import Path
from time import perf_counter
from unittest.mock import patch

from towel.cli import main
from towel.unification.annotation_ladder import Rejection
from towel.unification.fixed_point import FixedPointDrivers, _RejectedProposals
from towel.unification.materialize import Materialization

MODE = 'early'

import towel.unification.block_analysis as block_analysis
import towel.unification.pair_evaluation as pair_evaluation
from towel.unification.narrowing import caller_narrowing_leaves_with_block
boundary_calls = 0
boundary_seconds = 0.0
boundary_refusals = 0
def boundary(function, block):
    global boundary_calls, boundary_seconds, boundary_refusals
    started_boundary = perf_counter()
    result = caller_narrowing_leaves_with_block(function, block) if MODE == "early" else False
    boundary_calls += 1
    boundary_seconds += perf_counter() - started_boundary
    boundary_refusals += result
    return result
block_analysis.caller_narrowing_leaves_with_block = boundary
pair_evaluation.caller_narrowing_leaves_with_block = boundary

root = Path(__file__).parent
attempt = Materialization._attempt
decline = FixedPointDrivers._decline
materialize = Materialization._materialize_refactoring
events = []
started = perf_counter()
(root/'source.json').write_text(json.dumps({'towel':towel.__file__,'python':sys.version,'annotation_wiring_sha256':hashlib.sha256(Path(inspect.getfile(Materialization)).read_bytes()).hexdigest()},indent=2))

def record(event):
    event['elapsed'] = perf_counter() - started
    events.append(event)
    with (root/'events.jsonl').open('a') as stream:
        stream.write(json.dumps(event) + '\n')

def trial(self, variant, counters, check_types):
    sequence = sum(e['event'] == 'signature' for e in events)
    (root / f'variant-{sequence:02}.py').write_text(ast.unparse(ast.Module(body=[*variant.helper_type_declarations, variant.extracted_function], type_ignores=[])))
    (root / f'variant-{sequence:02}-context.json').write_text(json.dumps({'proposal':variant.description, 'path':variant.file_path, 'sites':[{'range':r.line_range, 'call':ast.unparse(r.node), 'source':Path(r.file_path or variant.file_path).read_text()} for r in variant.replacements]}, indent=2))
    result = attempt(self, variant, counters, check_types)
    record({'event':'signature', 'proposal':variant.description,
            'outcome':type(result).__name__,
            'errors':[str(error) for error in result.errors] if isinstance(result, Rejection) else []})
    return result

def rejected(self, proposal, reason):
    record({'event':'declined', 'proposal':proposal.description,
            'identity':_RejectedProposals.identity(proposal), 'reason':str(reason)})
    return decline(self, proposal, reason)

def rendered(self, proposal):
    record({'event':'proposal', 'proposal':proposal.description,
            'identity':_RejectedProposals.identity(proposal)})
    try:
        result=materialize(self,proposal)
    except Exception as error:
        record({'event':'failure', 'proposal':proposal.description,
                'error':type(error).__name__, 'detail':str(error)})
        raise
    record({'event':'materialized', 'proposal':proposal.description})
    return result

sys.argv=['towel','dry',str(root/'input/packaging'),str(root/'output'),
          '--no-interactive','--no-format','--progress','detail']
try:
    with patch.object(Materialization,'_attempt',trial), \
         patch.object(Materialization,'_materialize_refactoring',rendered), \
         patch.object(FixedPointDrivers,'_decline',rejected):
        main()
finally:
    counts=Counter(e['event'] for e in events)
    (root/'summary.json').write_text(json.dumps(dict(counts),indent=2))
    print('MEASURED',dict(counts),flush=True)

(root/"boundary.json").write_text(json.dumps({"calls":boundary_calls,"seconds":boundary_seconds,"refusals":boundary_refusals,"elapsed":perf_counter()-started}))
