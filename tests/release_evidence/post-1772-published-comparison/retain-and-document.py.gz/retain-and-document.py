"""Retain a completed measured comparison and generate a factual review draft.

No benchmark is launched here and no historical evidence is overwritten.
Complete source bodies stay in the external raw archive; repository evidence
retains their byte hashes and every other request field, plus all answers.
"""
from datetime import datetime
from pathlib import Path
import gzip, hashlib, json
P=Path(__file__).resolve().parent
read=lambda n:json.loads((P/n).read_text())
assert read('benchmark-result.json')['status']=='completed'
assert not (P/'retained-comparison').exists()
identity=read('wheel-source-identity.json')
order=['published','candidate','candidate','published']
packaging=read('packaging-results.json');sphinx=read('sphinx-results.json')
assert [r['arm'] for r in packaging]==[r['arm'] for r in sphinx]==order
ready=read('ready-for-timing.json')
assert datetime.fromisoformat(ready['created'])<=datetime.fromisoformat(packaging[0]['started'])
prerequisites=read('timing-prerequisites.json')
for row in prerequisites['completed']:
 assert row['status']=='completed' and datetime.fromisoformat(row['finished'])<=datetime.fromisoformat(ready['created'])
for r in packaging:
 assert r['exit_status']==0 and r['input_sha256']==read('input-provenance.json')['files']
 name=f"packaging-{r['run']}-{r['arm']}"
 assert read(name+'/runtime-identity.json')==identity[r['arm']]['runtime_sha256']
for arm in ('published','candidate'):
 rows=[r for r in packaging if r['arm']==arm]
 assert rows[0]['output_python_sha256']==rows[1]['output_python_sha256']
for key in ('request_sha256','request_fingerprints_sha256','answer_sha256'):
 assert len({r[key] for r in sphinx})==1
for r in sphinx:
 name=f"sphinx-{r['run']}-{r['arm']}"
 raw=(P/name/'requests.json').read_bytes();requests=json.loads(raw)
 assert hashlib.sha256(raw).hexdigest()==r['request_sha256']
 expected=[{**v,'source':{'sha256':hashlib.sha256(v['source'].encode()).hexdigest(),'bytes':len(v['source'].encode())}} for v in requests]
 compact=(P/name/'request-fingerprints.json').read_bytes()
 assert json.dumps(expected,sort_keys=True).encode()==compact
 assert hashlib.sha256(compact).hexdigest()==r['request_fingerprints_sha256']
 assert hashlib.sha256((P/name/'answers.json').read_bytes()).hexdigest()==r['answer_sha256']
 assert r['failed_files']=={}
state=read('sphinx-container-final.json')
assert state['State']['ExitCode']==0 and not state['State']['OOMKilled'] and state['HostConfig']['NetworkMode']=='none'
files=['benchmark-result.json','benchmark-driver.log','benchmark-result-stopped-20260928.json','benchmark-driver-stopped-20260928.log','published-provenance.json','pypi-1.772.json','wheel-source-identity.json','published-environment.json','candidate-environment.json','tool-pins.txt','input-provenance.json','run-after-validation.py','run-packaging.py','run-sphinx-container.py','profile-sphinx.py','packaging-results.json','packaging-comparison.json','packaging-driver.log','sphinx-results.json','sphinx-comparison.json','sphinx-driver.log','sphinx-container-command.json','sphinx-container-final.json','sphinx-resources.jsonl','sphinx-input-sha256.json','ready-for-timing.json','timing-prerequisites.json','retain-and-document.py']
for r in packaging:
 name=f"packaging-{r['run']}-{r['arm']}"
 files += [name+'/'+f for f in ('cli.log','imported-source.json','processes-before.txt','runtime-identity.json','command-result.json')]
for r in sphinx:
 name=f"sphinx-{r['run']}-{r['arm']}"
 files += [name+'/'+f for f in ('environment.json','result.json','request-fingerprints.json','answers.json')]
 files += [f"sphinx-{r['run']}-{suffix}.json" for suffix in ('install','source','command')]+[name+'.log']
files += [str(p.relative_to(P)) for p in (P/'prerequisites').rglob('*') if p.is_file()]
files += ['idle-preflight.json','processes-before-timing.txt']
assert len(files)==len(set(files)) and all((P/f).is_file() for f in files)
dest=P/'retained-comparison';dest.mkdir();records={}
for f in sorted(files):
 data=(P/f).read_bytes();name=f.replace('/','--')+'.gz';compressed=gzip.compress(data,mtime=0)
 assert gzip.decompress(compressed)==data
 (dest/name).write_bytes(compressed);records[name]={'source':f,'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()}
manifest={'archive_root':str(P),'retained_raw':records,'scope':'Published-wheel comparison; two observations per arm for full Packaging CLI and first Sphinx reveal. Full request bodies remain in raw external archive and have verified compact fingerprints.'}
(dest/'provenance.json').write_text(json.dumps(manifest,indent=2,sort_keys=True)+'\n')
text='''# Published 1.772 versus the next candidate

The baseline is the published PyPI wheel, not a rebuilt tag. Both artifacts
report version 1.772; their hashes distinguish them. These are measurements
of a development candidate; its artifact must not be uploaded as 1.772.

| Arm | Source commit | Wheel SHA-256 |
| --- | --- | --- |
'''
for arm in ('published','candidate'):
 r=identity[arm];text+=f"| {arm} | `{r['commit']}` | `{r['wheel_sha256']}` |\n"
text+='''
Each experiment used the order published, candidate, candidate, published.
Fresh input for each run; one Towel worker. The benchmark begins after the
corpus and serial matrix have completed, and after the supplemental validation
checks. The retained timestamps and prerequisites document that ordering.
Two observations per version do not establish a statistical confidence
interval. No whole-corpus speedup is established.

Validation and Git packing had finished before timing. Ordinary desktop
activity continued: the three-second preflight observed Mail using about
64% of one CPU and the Docker VM process about 33% of one CPU on the 18-core
host. This was not a dedicated idle machine. Process snapshots and the
alternating order expose some interference and drift; two samples cannot
eliminate every background-load confound.

| Measurement | Published mean seconds | Candidate mean seconds | Less time |
| --- | ---: | ---: | ---: |
'''
for label,rows,field,filename in [('Packaging',packaging,'seconds','packaging-comparison.json'),('Sphinx reveal',sphinx,'reveal_seconds','sphinx-comparison.json')]:
 means={arm:sum(r[field] for r in rows if r['arm']==arm)/2 for arm in ('published','candidate')};saved=read(filename)
 assert saved['means_seconds']==means
 percent=100*(1-means['candidate']/means['published']);assert abs(percent-saved['percent_less_time'])<1e-10
 text+=f"| {label} | {means['published']:.3f} | {means['candidate']:.3f} | {percent:.2f}% |\n"
text+='''
## Complete Packaging command

The Packaging samples show essentially unchanged elapsed time: a 0.51%
difference in means, with overlapping run times. This does not establish a
meaningful whole-command speedup over published 1.772. The candidate applied
19 extractions in nine files, versus 18 in eight files for the published
version, so the work performed also differs. The earlier approximately 16%
improvement compared intermediate commits; it is not the published-versus-final
result, and percentages from different baselines must not be added.

Packaging: whole unmodified CLI subprocess. The interval includes discovery,
type inference, proposal construction, checking, fixed-point extraction and
output writing. Environment setup and postchecks are outside it. The fixture
uses Packaging 26.3 with the same strict mypy configuration targeting Python
3.10, run on native CPython 3.13.7, macOS 26.5.1 arm64, M5 Max, 18 cores,
128 GiB. Both environments use identical dependency versions. Formatting and
cross-module extraction are disabled. This reproduces the earlier controlled
fixture; it is not a claim to run Packaging's entire upstream CI.

| Run | Arm | CLI seconds | Applied extractions | Changed files |
| --- | --- | ---: | ---: | ---: |
'''
for r in packaging:text+=f"| {r['run']} | {r['arm']} | {r['seconds']:.3f} | {r['applied_extractions']} | {r['changed_files']} |\n"
text+='''
Input bytes remained unchanged. Output Python bytes matched across both runs
of each version. The comparison preserves any difference in extraction counts
between versions; a timing reduction alone does not demonstrate equal output
or equivalent work. Complete logs retain each version's refusal summaries.
Runtime correctness is covered by the separately recorded validation, not by
the timer itself.

## Initial Sphinx type reveal

Sphinx: first production Pyright reveal only. The same observer calls each
installed version's unmodified reveal implementation, records its complete
requests and answers, then stops the CLI before extraction. Serialization is
outside the reveal timer. Sphinx extraction and runtime tests are outside this
timing. The run uses the same original Sphinx project, configuration and
checker pins in one offline Linux arm64 container (CPython 3.12.14); its Docker
VM has 18 CPUs and about 7.65 GiB. These are observed resources, not minimum
requirements. The container completed without OOM.

'''
env=read('sphinx-1-published/environment.json')
text+=f"{env['requests']:,} requests across {env['files']} files; {env['expressions']:,} expression probes and {sphinx[0]['answers']:,} reported types.\n"
text+='''Unanswered expression probes are not counted as inferred types. Identical
complete Sphinx requests and answers were verified across all four runs. The
retained request fingerprints preserve every field except source bodies,
which are represented by byte lengths and SHA-256 hashes. The raw archive
retains the original complete bodies and the retention script checks them
against those fingerprints.

| Run | Arm | Reveal seconds | Reported types |
| --- | --- | ---: | ---: |
'''
for r in sphinx:text+=f"| {r['run']} | {r['arm']} | {r['reveal_seconds']:.3f} | {r['answers']} |\n"
text+='''
## Evidence and interpretation

[Retained records](../../tests/release_evidence/post-1772-published-comparison/README.md)
include each command, imported runtime identity, wheel/source hashes, exact
dependency pins, request and answer hashes, timings, outputs and prerequisites.
The external raw archive is
`~/Knowledge/handoffs/towel/20260927T181305Z-codex-next-validation/performance-vs-1772`.
Documentary regressions reject changes in these historical facts and in their
scope. Intermediate optimization percentages are not added to this comparison.
'''
assert not (P/'published-1772-comparison.md').exists()
(P/'published-1772-comparison.md').write_text(text)
print('Retained',len(records),'records; provenance SHA-256',hashlib.sha256((dest/'provenance.json').read_bytes()).hexdigest())
