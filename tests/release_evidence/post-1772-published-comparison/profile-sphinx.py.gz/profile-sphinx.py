"""Observe the first production Pyright reveal, then deliberately stop.

This is a phase benchmark, never a full fixed-point extraction or release gate.
The same observer wraps both versions; it does not change requests or answers.
"""
from dataclasses import asdict
from pathlib import Path
from threading import Event, Thread
from time import perf_counter
from unittest.mock import patch
import hashlib
import importlib.metadata
import json
import sys
import towel
from towel.cli import main
from towel.type_inference import PyrightOracle

ROOT = Path(sys.argv[1])
ROOT.mkdir()
original = PyrightOracle.reveal
finished = Event()
started = perf_counter()


class Captured(Exception):
    pass


def reveal(self, requests):
    inputs = json.dumps([asdict(request) for request in requests], sort_keys=True).encode()
    (ROOT / 'requests.json').write_bytes(inputs)
    fingerprints = json.dumps([{**asdict(request), 'source': {'sha256': hashlib.sha256(request.source.encode()).hexdigest(), 'bytes': len(request.source.encode())}} for request in requests], sort_keys=True).encode()
    (ROOT / 'request-fingerprints.json').write_bytes(fingerprints)
    (ROOT / 'environment.json').write_text(json.dumps({'python': sys.version, 'towel': towel.__file__,
        'tools': {name: importlib.metadata.version(name) for name in ('code-towel', 'mypy', 'pyright', 'Sphinx')},
        'requests': len(requests), 'files': len({request.file_path for request in requests}),
        'expressions': sum(len(request.expressions) for request in requests)}, indent=2) + '\n')
    began = perf_counter()
    answer = original(self, requests)
    seconds = perf_counter() - began
    outputs = json.dumps({'answers': sorted(answer.items()), 'unanswered': dict(getattr(answer, 'unanswered', {}))}, sort_keys=True).encode()
    (ROOT / 'answers.json').write_bytes(outputs)
    (ROOT / 'result.json').write_text(json.dumps({'reveal_seconds': seconds,
        'observed_cli_seconds': perf_counter() - started,
        'request_sha256': hashlib.sha256(inputs).hexdigest(), 'request_fingerprints_sha256': hashlib.sha256(fingerprints).hexdigest(), 'answer_sha256': hashlib.sha256(outputs).hexdigest(),
        'answers': len(answer), 'failed_files': dict(getattr(answer, 'unanswered', {})),
        'scope': 'First production Pyright reveal only; observation stops before extraction.'}, indent=2) + '\n')
    raise Captured


def progress():
    while not finished.wait(30):
        print('Initial Pyright reveal still running:', round(perf_counter() - started), 'seconds', flush=True)


watcher = Thread(target=progress, daemon=True)
watcher.start()
sys.argv = ['towel', 'dry', '/work/sphinx-ready/sphinx', '/work/unused-output',
            '--cross-module', '--no-interactive', '--no-format', '--progress', 'detail']
try:
    with patch.object(PyrightOracle, 'reveal', reveal):
        main()
except Captured:
    print('INITIAL PYRIGHT REVEAL CAPTURED; full extraction deliberately not run.', flush=True)
else:
    raise RuntimeError('The production path did not reach the intended Pyright reveal.')
finally:
    finished.set()
    watcher.join()
