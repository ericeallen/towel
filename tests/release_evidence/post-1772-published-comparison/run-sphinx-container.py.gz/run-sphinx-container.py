"""Offline private-copy phase comparison; never touches the corpus volume."""
from pathlib import Path
from datetime import datetime, timezone
from time import perf_counter
import hashlib
import json
import os
import shutil
import signal
import subprocess
import zipfile

ROOT = Path('/evidence')
WORK = Path('/work')
IDENTITY = json.loads((ROOT / 'wheel-source-identity.json').read_text())
ORDER = ('published', 'candidate', 'candidate', 'published')


def now():
    return datetime.now(timezone.utc).isoformat()


def hashes(directory):
    return {str(path.relative_to(directory)): hashlib.sha256(path.read_bytes()).hexdigest()
            for path in sorted(directory.rglob('*.py')) if '__pycache__' not in path.parts}


assert not (WORK / 'sphinx-env').exists(), 'Never reuse previous benchmark state.'
shutil.copytree('/seed/sphinx-env', WORK / 'sphinx-env', symlinks=True)
python = str(WORK / 'sphinx-env/bin/python')
env = os.environ.copy()
env['TOWEL_WORKERS'] = '1'
env['PYTHONHASHSEED'] = '0'
env['UV_OFFLINE'] = '1'
env['UV_CACHE_DIR'] = '/work/.uv-cache'
env['VIRTUAL_ENV'] = str(WORK / 'sphinx-env')
env['PATH'] = str(WORK / 'sphinx-env/bin') + os.pathsep + env['PATH']
for name in ('PYTHONPATH', 'PYRIGHT_PYTHON_FORCE_VERSION', 'PYTEST_ADDOPTS', 'COVERAGE_RCFILE', 'COVERAGE_PROCESS_START', 'PYTHONHOME', 'MYPY_CACHE_DIR', 'MYPYPATH', 'MYPY_CONFIG_FILE'):
    env.pop(name, None)
original = hashes(Path('/seed/sphinx'))
(ROOT / 'sphinx-input-sha256.json').write_text(json.dumps(original, indent=2) + '\n')
results = []
for index, label in enumerate(ORDER, 1):
    print('PREPARE', index, label, now(), flush=True)
    ready = WORK / 'sphinx-ready'
    assert not ready.exists()
    shutil.copytree('/seed/sphinx', ready, symlinks=True,
                    ignore=shutil.ignore_patterns('.mypy_cache', '.pytest_cache', '__pycache__'))
    assert hashes(ready) == original
    clean = subprocess.run(['git', '-c', 'safe.directory=/work/sphinx-ready', '-C', str(ready), 'diff', '--exit-code', 'HEAD'], capture_output=True, text=True)
    assert clean.returncode == 0, clean.stdout
    wheel = Path('/published/code_towel-1.772-py3-none-any.whl') if label == 'published' else Path('/candidate-wheel/code_towel-1.772-py3-none-any.whl')
    assert hashlib.sha256(wheel.read_bytes()).hexdigest() == IDENTITY[label]['wheel_sha256']
    command = ['uv', 'pip', 'install', '--offline', '--no-deps', '--reinstall-package', 'code-towel', '--python', python, str(wheel)]
    result = subprocess.run(command, env=env, text=True, capture_output=True)
    (ROOT / f'sphinx-{index}-install.json').write_text(json.dumps({'command': command, 'exit_status': result.returncode, 'stdout': result.stdout, 'stderr': result.stderr}, indent=2) + '\n')
    assert result.returncode == 0, result.stderr
    actual = Path(subprocess.check_output([python, '-c', 'import towel;print(towel.__file__)'], env=env, text=True).strip()).parent
    assert actual.is_relative_to(WORK / 'sphinx-env')
    with zipfile.ZipFile(wheel) as archive:
        expected = {name.removeprefix('towel/'): archive.read(name) for name in archive.namelist() if name.startswith('towel/') and not name.endswith('/')}
    for name, data in expected.items():
        assert (actual / name).read_bytes() == data, name
    assert {str(path.relative_to(actual)) for path in actual.rglob('*.py')} == {name for name in expected if name.endswith('.py')}
    (ROOT / f'sphinx-{index}-source.json').write_text(json.dumps({'arm': label, 'source': str(actual), 'wheel_sha256': IDENTITY[label]['wheel_sha256'], 'verified_runtime_files': len(expected)}, indent=2) + '\n')
    directory = ROOT / f'sphinx-{index}-{label}'
    command = [python, str(ROOT / 'profile-sphinx.py'), str(directory)]
    started = now()
    began = perf_counter()
    print('START', index, label, started, flush=True)
    with (ROOT / f'sphinx-{index}-{label}.log').open('w') as log:
        process = subprocess.Popen(command, cwd=ready, env=env, stdout=log, stderr=subprocess.STDOUT, start_new_session=True)
        try:
            status = process.wait(timeout=3600)
        finally:
            try:
                os.killpg(process.pid, signal.SIGTERM)
            except ProcessLookupError:
                pass
            process.wait()
    command_result = {'arm': label, 'command': command, 'started': started, 'finished': now(), 'seconds': perf_counter() - began, 'exit_status': status}
    (ROOT / f'sphinx-{index}-command.json').write_text(json.dumps(command_result, indent=2) + '\n')
    assert status == 0, command_result
    measured = json.loads((directory / 'result.json').read_text())
    assert measured['failed_files'] == {} and measured['answers'] > 0
    assert hashes(ready) == original, 'Probe-only CLI changed original Sphinx source.'
    results.append({'arm': label, 'run': index, **measured})
    (ROOT / 'sphinx-results.json').write_text(json.dumps(results, indent=2) + '\n')
    ready.rename(WORK / f'sphinx-input-completed-{index}')
    print('END', index, label, measured['reveal_seconds'], flush=True)
assert len({row['request_sha256'] for row in results}) == 1
assert len({row['request_fingerprints_sha256'] for row in results}) == 1
assert len({row['answer_sha256'] for row in results}) == 1
means = {arm: sum(row['reveal_seconds'] for row in results if row['arm'] == arm) / 2 for arm in ('published', 'candidate')}
comparison = {'means_seconds': means, 'speedup_factor': means['published'] / means['candidate'], 'percent_less_time': 100 * (1 - means['candidate'] / means['published']), 'requests_identical': True, 'answers_identical': True, 'scope': 'First production Pyright reveal only; same existing project configuration/checkers; no full fixed-point extraction or runtime test claim.'}
(ROOT / 'sphinx-comparison.json').write_text(json.dumps(comparison, indent=2) + '\n')
print(json.dumps(comparison), flush=True)
