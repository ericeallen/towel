"""Run approved comparisons after heavy validation and an explicit quiet-work marker."""
from pathlib import Path
from datetime import datetime, timezone
from time import monotonic, sleep
import json
import subprocess
import threading

ROOT = Path(__file__).resolve().parent
CANDIDATE = ROOT.parent / 'release-gates-3af8c4b'


def now():
    return datetime.now(timezone.utc).isoformat()


def run():
    assert not (ROOT / 'benchmark-result.json').exists(), 'Inspect existing comparison, never overwrite.'
    deadline = monotonic() + 18 * 3600
    while True:
        final = CANDIDATE / 'continuation-result.json'
        if final.exists():
            status = json.loads(final.read_text())
            assert status['status'] == 'mechanical_gates_complete', status
            if (ROOT / 'ready-for-timing.json').exists():
                break
        if monotonic() >= deadline:
            raise RuntimeError('Wait expired; inspect active jobs, no benchmark started.')
        print(now(), 'Waiting for completed matrix and explicit quiet-work marker.', flush=True)
        sleep(50)
    running = subprocess.check_output(['docker', 'ps', '--format', '{{.Names}}'], text=True).splitlines()
    assert not running, ('Competing Docker work prevents controlled comparison', running)
    with (ROOT / 'packaging-driver.log').open('w') as log:
        subprocess.run(['python3', '-u', str(ROOT / 'run-packaging.py')], cwd=ROOT, stdout=log, stderr=subprocess.STDOUT, check=True)
    volume = 'towel-benchmark-1772-20260928'
    volumes = subprocess.check_output(['docker', 'volume', 'ls', '--format', '{{.Name}}'], text=True).splitlines()
    assert volume not in volumes, 'Do not reuse benchmark scratch state.'
    command = ['docker', 'run', '-d', '--name', 'towel-benchmark-1772-20260928', '--init', '--network', 'none', '--user', 'root',
        '-e', 'UV_OFFLINE=1', '-v', 'towel-next-offline-deps-20260927:/seed:ro', '-v', volume + ':/work',
        '-v', str(ROOT) + ':/evidence', '-v', str(ROOT / 'published') + ':/published:ro',
        '-v', str(CANDIDATE / 'dist') + ':/candidate-wheel:ro',
        'sha256:47fe32ba90ea4d65f85dd24fb3a93f754e8e3fa922a58930f88e8e0461b6d6d8', 'python', '-u', '/evidence/run-sphinx-container.py']
    started = now()
    container = subprocess.check_output(command, text=True).strip()
    (ROOT / 'sphinx-container-command.json').write_text(json.dumps({'command': command, 'started': started, 'container': container}, indent=2) + '\n')
    stopped = threading.Event()
    def sample():
        with (ROOT / 'sphinx-resources.jsonl').open('w') as log:
            while not stopped.is_set():
                result = subprocess.run(['docker', 'stats', '--no-stream', '--format', '{{json .}}', container], capture_output=True, text=True)
                log.write(json.dumps({'observed': now(), 'exit_status': result.returncode, 'stats': result.stdout.strip(), 'stderr': result.stderr.strip()}) + '\n')
                log.flush()
                stopped.wait(15)
    sampler = threading.Thread(target=sample)
    sampler.start()
    try:
        with (ROOT / 'sphinx-driver.log').open('w') as log:
            follower = subprocess.Popen(['docker', 'logs', '--follow', container], stdout=log, stderr=subprocess.STDOUT)
            status = int(subprocess.check_output(['docker', 'wait', container], text=True).strip())
            follower.wait()
    finally:
        stopped.set()
        sampler.join()
    inspection = json.loads(subprocess.check_output(['docker', 'inspect', container], text=True))[0]
    (ROOT / 'sphinx-container-final.json').write_text(json.dumps(inspection, indent=2) + '\n')
    assert status == 0 and not inspection['State']['OOMKilled'], inspection['State']
    assert inspection['HostConfig']['NetworkMode'] == 'none'
    assert inspection['Image'] == 'sha256:47fe32ba90ea4d65f85dd24fb3a93f754e8e3fa922a58930f88e8e0461b6d6d8'
    assert (ROOT / 'packaging-comparison.json').is_file() and (ROOT / 'sphinx-comparison.json').is_file()
    print(now(), 'Controlled comparisons complete; review scope and raw outputs before documenting.', flush=True)


try:
    run()
except BaseException as error:
    (ROOT / 'benchmark-result.json').write_text(json.dumps({'finished': now(), 'status': 'stopped_for_review', 'error': repr(error)}, indent=2) + '\n')
    raise
else:
    (ROOT / 'benchmark-result.json').write_text(json.dumps({'finished': now(), 'status': 'completed'}, indent=2) + '\n')
