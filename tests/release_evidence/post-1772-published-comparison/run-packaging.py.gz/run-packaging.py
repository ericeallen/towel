"""Compare actual installed wheels using an unmodified, complete typed CLI.

Four sequential fresh-input runs use released/candidate/candidate/released order.
The timer encloses the CLI subprocess (not setup, imports proof, or postchecks).
Never run while other validation/benchmark work is active; retain CPU observations.
"""
from pathlib import Path
from datetime import datetime, timezone
from time import perf_counter
import hashlib
import json
import os
import re
import shutil
import subprocess

ROOT = Path(__file__).resolve().parent
IDENTITY = json.loads((ROOT / 'wheel-source-identity.json').read_text())
ORDER = ('published', 'candidate', 'candidate', 'published')


def now():
    return datetime.now(timezone.utc).isoformat()


def hashes(directory):
    return {str(path.relative_to(directory)): hashlib.sha256(path.read_bytes()).hexdigest()
            for path in sorted(directory.rglob('*')) if path.is_file()
            and not any(part in {'__pycache__', '.mypy_cache', '.ruff_cache'} for part in path.relative_to(directory).parts)}


def run():
    assert not (ROOT / 'packaging-results.json').exists(), 'Do not overwrite measured results.'
    metadata = [json.loads((ROOT / (label + '-environment.json')).read_text()) for label in ('published', 'candidate')]
    assert metadata[0]['versions'] == metadata[1]['versions']
    assert metadata[0]['python'] == metadata[1]['python']
    source_hashes = hashes(ROOT / 'input')
    assert source_hashes == json.loads((ROOT / 'input-provenance.json').read_text())['files']
    env = os.environ.copy()
    for name in ('PYTHONPATH', 'PYTEST_ADDOPTS', 'PYRIGHT_PYTHON_FORCE_VERSION', 'COVERAGE_RCFILE', 'COVERAGE_PROCESS_START', 'PYTHONHOME', 'MYPY_CACHE_DIR', 'MYPYPATH', 'MYPY_CONFIG_FILE'):
        env.pop(name, None)
    env['TOWEL_WORKERS'] = '1'
    env['UV_CACHE_DIR'] = '/private/tmp/towel-post-1772-uv-cache'
    env['PYTHONHASHSEED'] = '0'
    rows = []
    for index, label in enumerate(ORDER, 1):
        directory = ROOT / f'packaging-{index}-{label}'
        directory.mkdir()
        shutil.copytree(ROOT / 'input', directory / 'input')
        venv = ROOT / ('venv-' + label)
        run_env = dict(env, PATH=str(venv / 'bin') + os.pathsep + env['PATH'], VIRTUAL_ENV=str(venv))
        before = hashes(directory / 'input')
        assert before == source_hashes
        imported = subprocess.check_output([str(venv / 'bin/python'), '-c',
            "from pathlib import Path;import json,sys,towel;from importlib.metadata import distributions;print(json.dumps({'source':str(Path(towel.__file__).resolve()),'python':sys.version,'versions':{d.metadata['Name']:d.version for d in distributions()}}))"], cwd=directory, env=run_env, text=True)
        imported_record = json.loads(imported)
        actual = Path(imported_record['source']).parent
        assert actual.is_relative_to(venv)
        expected_environment = metadata[0 if label == 'published' else 1]
        assert imported_record['versions'] == expected_environment['versions']
        assert imported_record['python'] == expected_environment['python']
        installed_hashes = {'towel/' + name: digest for name, digest in hashes(actual).items()}
        assert installed_hashes == IDENTITY[label]['runtime_sha256'], 'Installed wheel runtime drifted after setup.'
        assert hashlib.sha256(Path(IDENTITY[label]['wheel_path']).read_bytes()).hexdigest() == IDENTITY[label]['wheel_sha256']
        (directory / 'runtime-identity.json').write_text(json.dumps(installed_hashes, indent=2) + '\n')
        (directory / 'imported-source.json').write_text(imported)
        processes = subprocess.run(['ps', '-axo', 'pid,ppid,%cpu,%mem,comm'], capture_output=True, text=True)
        assert processes.returncode == 0, 'Benchmark needs process visibility to assess interference.'
        (directory / 'processes-before.txt').write_text(processes.stdout)
        command = [str(venv / 'bin/towel'), 'dry', str(directory / 'input/packaging'), str(directory / 'output'),
                   '--no-interactive', '--no-format', '--progress', 'detail']
        print('START', index, label, now(), flush=True)
        started = now()
        began = perf_counter()
        with (directory / 'cli.log').open('w') as log:
            result = subprocess.run(command, cwd=directory / 'input', env=run_env, stdout=log, stderr=subprocess.STDOUT)
        seconds = perf_counter() - began
        record = {'arm': label, 'run': index, 'command': command, 'cwd': str(directory / 'input'),
                  'started': started, 'finished': now(), 'seconds': seconds, 'exit_status': result.returncode,
                  'environment': {'TOWEL_WORKERS': '1', 'PYTHONHASHSEED': '0', 'formatting': False, 'cross_module': False},
                  'wheel_sha256': IDENTITY[label]['wheel_sha256'], 'source_commit': IDENTITY[label]['commit']}
        (directory / 'command-result.json').write_text(json.dumps(record, indent=2) + '\n')
        assert result.returncode == 0, (directory, result.returncode)
        text = (directory / 'cli.log').read_text()
        matches = re.findall(r'Applied (\d+) refactoring\(s\) across (\d+) file\(s\)', text)
        assert len(matches) == 1 and int(matches[0][0]) > 0, text[-2000:]
        assert not any(marker in text for marker in ('not inferred or verified', 'rerun without types'))
        assert hashes(directory / 'input') == before, 'The production dry run changed original input.'
        output = hashes(directory / 'output')
        python_output = {name: digest for name, digest in output.items() if name.endswith('.py')}
        assert len(python_output) == 22
        record.update({'applied_extractions': int(matches[0][0]), 'changed_files': int(matches[0][1]),
                       'input_sha256': before, 'output_python_sha256': python_output,
                       'declined_summary': [line.strip() for line in text.splitlines() if 'proposal(s) not applied:' in line]})
        rows.append(record)
        (ROOT / 'packaging-results.json').write_text(json.dumps(rows, indent=2) + '\n')
        print('END', index, label, result.returncode, round(seconds, 3), 'seconds', matches[0], flush=True)
    for arm in ('published', 'candidate'):
        selected = [row for row in rows if row['arm'] == arm]
        assert selected[0]['output_python_sha256'] == selected[1]['output_python_sha256'], arm
    means = {arm: sum(row['seconds'] for row in rows if row['arm'] == arm) / 2 for arm in ('published', 'candidate')}
    comparison = {'source_identity': IDENTITY, 'means_seconds': means,
                  'percent_less_time': 100 * (1 - means['candidate'] / means['published']),
                  'outputs_identical_within_each_arm': True,
                  'scope': 'Whole unmodified CLI subprocess, fresh input each run, strict mypy Python3.10 target, Python3.13.7 host, one worker, no formatter, no cross-module. Four sequential runs, not a corpus-wide claim. Source inputs preserved; runtime tests are separate from these timings.'}
    (ROOT / 'packaging-comparison.json').write_text(json.dumps(comparison, indent=2) + '\n')
    print(json.dumps({'means_seconds': means, 'percent_less_time': comparison['percent_less_time']}), flush=True)


if __name__ == '__main__':
    run()
