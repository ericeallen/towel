from concurrent.futures import ThreadPoolExecutor
from datetime import datetime, timezone
from pathlib import Path
import json
import subprocess
import threading
import time

ROOT = Path(__file__).resolve().parent
IMAGE = "towel-next-matrix:procps-20260927"

def now():
    return datetime.now(timezone.utc).isoformat()

def run(version):
    commit = subprocess.check_output(["git", "-C", str(ROOT / "candidate"), "rev-parse", "HEAD"], text=True).strip()
    name = "towel-next-final-" + version.replace(".", "") + "-" + commit[:7]
    args = ["docker", "run", "-d", "--name", name, "--init", "--network", "none", "--user", "root", "-e", "UV_OFFLINE=1", "-v", "towel-next-matrix-20260927:/work", "-v", str(ROOT / "candidate") + ":/candidate:ro", "-v", str(ROOT) + ":/evidence", IMAGE, "bash", "-c", f"bash /evidence/run-matrix.sh {version} > /evidence/matrix-{version}.log 2>&1"]
    started = now()
    container = subprocess.check_output(args, text=True).strip()
    (ROOT / f"matrix-{version}-launch.json").write_text(json.dumps({"args": args, "container": container, "started": started, "commit": commit}, indent=2) + "\n")
    done = threading.Event()
    def sample():
        with (ROOT / f"matrix-{version}-resources.jsonl").open("w") as record:
            while not done.is_set():
                result = subprocess.run(["docker", "stats", "--no-stream", "--format", "{{json .}}", container], text=True, capture_output=True)
                record.write(json.dumps({"time": now(), "status": result.returncode, "docker_stats": result.stdout.strip(), "error": result.stderr.strip()}) + "\n")
                record.flush()
                done.wait(15)
    sampler = threading.Thread(target=sample)
    sampler.start()
    print("START", version, commit, started, flush=True)
    try:
        status = int(subprocess.check_output(["docker", "wait", container], text=True).strip())
    finally:
        done.set()
        sampler.join()
    (ROOT / f"matrix-{version}-container.json").write_text(subprocess.check_output(["docker", "inspect", container], text=True))
    print("END", version, status, now(), flush=True)
    return status

if __name__ == "__main__":
    for old in ("towel-next-matrix-311-r2", "towel-next-matrix-313-r3"):
        state = json.loads(subprocess.check_output(["docker", "inspect", old], text=True))[0]["State"]
        assert not state["Running"], (old, state)
    (ROOT / "matrix-image.json").write_text(subprocess.check_output(["docker", "image", "inspect", IMAGE], text=True))
    with ThreadPoolExecutor(max_workers=1) as pool:
        results = list(pool.map(run, ("3.11", "3.13", "3.12")))
    raise SystemExit(any(results))
