from pathlib import Path
import base64
import configparser
import csv
import hashlib
import io
import json
import subprocess
import tarfile
import zipfile

root = Path(__file__).resolve().parent
source = root / "candidate"
commit = subprocess.check_output(["git", "-C", str(source), "rev-parse", "HEAD"], text=True).strip()
archive_bytes = subprocess.check_output(["git", "-C", str(source), "archive", "HEAD"])
with tarfile.open(fileobj=io.BytesIO(archive_bytes)) as archive:
    tracked = {m.name: archive.extractfile(m).read() for m in archive.getmembers() if m.isfile()}
runtime = {name.removeprefix("src/"): data for name, data in tracked.items() if name.startswith("src/towel/")}
wheel = root / "dist/code_towel-1.772-py3-none-any.whl"
with zipfile.ZipFile(wheel) as archive:
    names = archive.namelist()
    assert len(names) == len(set(names))
    contents = {name: archive.read(name) for name in names}
    assert {name: data for name, data in contents.items() if name.startswith("towel/")} == runtime
    record_name = "code_towel-1.772.dist-info/RECORD"
    rows = list(csv.reader(io.StringIO(contents[record_name].decode())))
    assert len(rows) == len(contents) and {row[0] for row in rows} == set(contents)
    for name, digest, size in rows:
        if name == record_name:
            assert digest == size == ""
        else:
            assert digest == "sha256=" + base64.urlsafe_b64encode(hashlib.sha256(contents[name]).digest()).decode().rstrip("=")
            assert int(size) == len(contents[name])
sdist = root / "dist/code_towel-1.772.tar.gz"
with tarfile.open(sdist) as archive:
    files = [m for m in archive.getmembers() if m.isfile()]
    packaged = {m.name.removeprefix("code_towel-1.772/"): archive.extractfile(m).read() for m in files}
    assert len(packaged) == len(files)
for name in set(packaged) & set(tracked) - {"setup.cfg"}:
    assert packaged[name] == tracked[name], name
before = configparser.ConfigParser(interpolation=None)
before.read_string(tracked["setup.cfg"].decode())
after = configparser.ConfigParser(interpolation=None)
after.read_string(packaged["setup.cfg"].decode())
assert set(after.sections()) == set(before.sections()) | {"egg_info"}
assert dict(after["egg_info"]) == {"tag_build": "", "tag_date": "0"}
assert all(dict(before[section]) == dict(after[section]) for section in before.sections())
expected_metadata = {
    "PKG-INFO", "src/code_towel.egg-info/PKG-INFO", "src/code_towel.egg-info/SOURCES.txt",
    "src/code_towel.egg-info/dependency_links.txt", "src/code_towel.egg-info/entry_points.txt",
    "src/code_towel.egg-info/requires.txt", "src/code_towel.egg-info/top_level.txt",
}
assert set(packaged) - set(tracked) == expected_metadata
assert all("src/" + name in packaged and packaged["src/" + name] == data for name, data in runtime.items())
assert all(name in packaged for name in tracked if name.startswith("tests/") and Path(name).suffix in {".py", ".pynew", ".md", ".toml", ".ini"})
result = {
    "commit": commit, "runtime_files": len(runtime), "record_entries_verified": len(rows),
    "sdist_files": len(packaged), "tracked_sdist_files_matching_commit": len(set(packaged) & set(tracked)) - 1,
    "normalized_setup_cfg": "Identical configuration plus neutral setuptools egg_info section",
    "tracked_files_excluded_from_sdist": sorted(set(tracked) - set(packaged)),
    "nontracked_sdist_files": sorted(expected_metadata), "status": "passed",
}
(root / "distribution-contents.json").write_text(json.dumps(result, indent=2) + "\n")
print(json.dumps({key: value for key, value in result.items() if key != "tracked_files_excluded_from_sdist"}, indent=2))
